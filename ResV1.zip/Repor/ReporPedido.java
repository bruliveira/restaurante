package Repor;

import java.util.ArrayList;
import java.util.Scanner;

import Classes.*;

public class ReporPedido {
	Scanner scanner = new Scanner(System.in);
	
	private int id = 0;
	private int nMaxMesa = 20;
	
	private  static ArrayList<Pedido> lisPedidos = new ArrayList<Pedido>();
	private  static ArrayList<Pedido> lisPedidosPg = new ArrayList<Pedido>();
	private  static ArrayList<Pedido> lisPedidosNPg = new ArrayList<Pedido>();
	
	// inicio das funcoes get/set
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getnMaxMesa() {
		return nMaxMesa;
	}

	public void setnMaxMesa(int nMaxMesa) {
		this.nMaxMesa = nMaxMesa;
	}

	public static ArrayList<Pedido> getLisPedidos() {
		return lisPedidos;
	}

	public static void setLisPedidos(ArrayList<Pedido> lisPedidos) {
		ReporPedido.lisPedidos = lisPedidos;
	}

	public static ArrayList<Pedido> getLisPedidosPg() {
		return lisPedidosPg;
	}

	public static void setLisPedidosPg(ArrayList<Pedido> lisPedidosPg) {
		ReporPedido.lisPedidosPg = lisPedidosPg;
	}

	public static ArrayList<Pedido> getLisPedidosNPg() {
		return lisPedidosNPg;
	}

	public static void setLisPedidosNPg(ArrayList<Pedido> lisPedidosNPg) {
		ReporPedido.lisPedidosNPg = lisPedidosNPg;
	}
		
	// fim das funcoes get/set
	
	//add novo pedido
	public Pedido AddPedido()
	{
		Pedido p = new Pedido();
		int mesa;
		//id +=1;
		boolean v = true;
		do
		{
			try
			{	
				System.out.println("numero da mesa : ");
				mesa = scanner.nextInt();
				p = BuscarMesa(mesa);
				
				if(p != null)
				{
					v = false;
				}
				
			}catch(Exception e)
			{
				scanner.next();
				mesa = 0;
			}
			
			if((mesa > nMaxMesa || mesa < 0))
			{
				System.out.println("----- mesa indisponivel -----");
			}
			
		}while((mesa > nMaxMesa || mesa < 0));
		//scanner.nextLine();
		//BuscarMesa(mesa);
		if(v)
		{
			id +=1;
			Pedido p1 = new Pedido(mesa,id);
			lisPedidos.add(p1);
			scanner.nextLine();
			System.out.println("novo pedido");
			return p1;
		}
		else
		{
			System.out.println(" pedido ja existe");
			return p;
		}
		//return p;
		
	}
	
	//remover pedido
	public void RemoverPedido()
	{
		int nId;
		Pedido p;
		do
		{
			try
			{
			System.out.println("digite o id");
			nId = scanner.nextInt();
			}
			catch(Exception e)
			{
				System.out.println("digite um numero");
				scanner.next();
				nId = 0;
			}
			p = Buscar(nId);
			if(p != null)
			{
				lisPedidosNPg.remove(p);
			}
			else
			{
				System.out.println("numero invalido digite outro\n");
			}
			
			
		}while(p == null);
	}
	
	/*
	public void EditarPedido()
	{
		
	}
	*/
	
	//fazer o pagamento do pedido
	public void Finalizar()
	{
		int nId;
		Pedido p;
		double d;
		do
		{
			try
			{
			System.out.println("digite o id");
			nId = scanner.nextInt();
			}
			catch(Exception e)
			{
				System.out.println("digite um numero");
				scanner.next();
				nId = 0;
			}
			p = Buscar(nId);
		}while(p == null);
		
		do
		{
			try
			{
				System.out.println("valor pago : ");
				d = scanner.nextDouble();
				if(d < 0)
				{
					System.out.println("------digite uma quantia valido -----");
				}
			}catch(Exception e)
			{
				System.out.println("----- digite uma quantia valido -----");
				d = -1;
			}
		}while(d < 0 );
		
		if(d > p.getPrecoTotal())
		{
			d -= p.getPrecoTotal();
			System.out.println("pedido finalizado");
			System.out.println("troco: " + d);
			p.MostraPedido();
			p.setPg(true);
			lisPedidosPg.add(p);
			lisPedidosNPg.remove(p);
		}
		else if(d < p.getPrecoTotal())
		{
			System.out.println("falta " + (p.getPrecoTotal() - d ) + " para finalizar o pedido");
			p.setJpg(d);
			p.setPrecoTotal(d);
		}
		else
		{
			System.out.println("pedido finalizado");
			p.MostraPedido();
			p.setPg(true);
			lisPedidosPg.add(p);
			lisPedidosNPg.remove(p);
		}
	}
	
	//mostra todos os pedidos
	public void MostraPedidos()
	{
		System.out.println("|id \t| n mesa | preco | pago|");
		for(Pedido p : lisPedidos)
		{
			System.out.println("|" + p.getId() + "\t|" + p.getMesa() + "\t|" + p.getPrecoTotal() + "\t|" + p.getPg() + "\t|");
		}
	}
	
	//buscar nos pedidos q ainda nao foram pagos // esta funcao faz praticamente a mesma coisa da buscar mesa so q com um id kkkk
	public Pedido Buscar(int n)
	{
		
		for(Pedido p : lisPedidosNPg)
		{
			
			if(n == p.getId())
			{
				return p;
			}
			
		}
		return null;
	}
	
	//saber qual pedido pertence a deteminada mesa
	public Pedido BuscarMesa(int n)
	{
		for(Pedido p : lisPedidosNPg)
		{
			
			if(n == p.getMesa())
			{
				return p;
			}
			
		}
		
		return null;
	}
	
}
