package Repor;

import java.util.ArrayList;
import java.util.Scanner;

import Classes.*;

public class ReporProduto {
	///fazer funcao para nao colocar produtos repetidos
	
	Scanner scanner = new Scanner(System.in);
	private int id = 0;
	private static ArrayList<Comida> lisComida = new ArrayList<Comida>();
	private static ArrayList<Bebida> lisBebida = new ArrayList<Bebida>();
	
	public static void Criar()
	{
		Comida c = new Comida("comida","arroz",3,10);
		Bebida b = new Bebida("bebida","suco",5,15);
		lisComida.add(c);
		lisBebida.add(b);
	}
	
	// inicio das funcoes get/set
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public static ArrayList<Comida> getLisComida() {
		return lisComida;
	}


	public static void setLisComida(ArrayList<Comida> lisComida) {
		ReporProduto.lisComida = lisComida;
	}


	public static ArrayList<Bebida> getLisBebida() {
		return lisBebida;
	}


	public static void setLisBebida(ArrayList<Bebida> lisBebida) {
		ReporProduto.lisBebida = lisBebida;
	}
	// inicio das funcoes get/set
	
	//add produto no cardapio
	public void AddProduto(String tipo)
	{
		String nome;
		double preco;
		id +=1;
		Produto p;
		
		
		System.out.println("nome : ");
		nome = scanner.nextLine();
		
		do
		{
			try
			{
				System.out.println("preco : ");
				preco = scanner.nextDouble();
			}catch(Exception e)
			{
				preco = -1;
				scanner.next();
			}
		}while(preco < 0);
		
		scanner.nextLine();
		
		if(tipo == "comida") {
			
			lisComida.add(new Comida(tipo,nome,preco,id));	
		}
		else
		{
			lisBebida.add(new Bebida(tipo,nome,preco,id));
		}
		
		p = Buscar(id,tipo);
		System.out.println("novo produto add");
		System.out.println("|id \t| nome \t| preco|");
		System.out.println("|" + p.getId() + "\t|" + p.getNome() + "\t|" + p.getPreco() + "\t|");
		System.out.println("\naperte ENTER para voltar");
		scanner.nextLine();
		
	}
	
	//remover produto do cardapio
	public void RemoverProduto(String tipo)
	{
		int nId;
		Produto p;
		do
		{
			try
			{
			System.out.println("digite o id");
			nId = scanner.nextInt();
			}
			catch(Exception e)
			{
				scanner.next();
				nId = 0;
			}
			p = Buscar(nId,tipo);
			if(p != null)
			{
				if(tipo == "comida")
				{
					lisComida.remove(p);
				}
				else
				{
					lisBebida.remove(p);
				}
			}
			else
			{
				System.out.println("----- id invalido -----");
			}
			
			
		}while(p == null);
		
		System.out.println("produto removido");
		System.out.println("|id \t| nome \t| preco|");
		System.out.println("|" + p.getId() + "\t|" + p.getNome() + "\t|" + p.getPreco() + "\t|");
		System.out.println("\naperte ENTER para voltar");
		scanner.nextLine();
		scanner.nextLine();
	}
	
	//modificar dados do produto no cardapio
	public void EditarProduto(String tipo)
	{
		int nId;
		Produto p;
		
		do
		{
			try
			{
			System.out.println("digite o id");
			nId = scanner.nextInt();
			}
			catch(Exception e)
			{
				System.out.println("digite um numero");
				scanner.next();
				nId = 0;
			}
			p = Buscar(nId,tipo);
			if(p != null)
			{
				System.out.println("novo nome: ");
				scanner.nextLine();
				p.setNome(scanner.nextLine());
				
				do
				{
					try
					{
						System.out.println("novo preco : ");
						p.setPreco(scanner.nextDouble());
						
						if(p.getPreco() < 0)
						{
							System.out.println("----- digite um preco valido -----");
						}
						
					}
					catch(Exception e)
					{
						System.out.println("----- digite um preco valido -----");
						scanner.next();
						p.setPreco(-1);
					}
				}while(p.getPreco() < 0);
			}
			else
			{
				System.out.println("numero invalido digite outro");
			}
			
			
		}while(p == null);
		
		System.out.println("novos dados do produto ");
		System.out.println("|id \t| nome \t| preco|");
		System.out.println("|" + p.getId() + "\t|" + p.getNome() + "\t|" + p.getPreco() + "\t|");
		System.out.println("\naperte ENTER para voltar");
		scanner.nextLine();
		scanner.nextLine();
		
	}
	
	//ver o cardapio
	public void VerProdutos()
	{
		System.out.println("\t comida");
		System.out.println("|id \t| nome \t| preco |");
		for(Comida c : lisComida)
		{
			System.out.println("|" + c.getId() + "\t|" + c.getNome() + "\t|" + c.getPreco() + "\t|");
			
		}
		
		System.out.println();
		System.out.println("\t bebida");
		System.out.println("|id \t| nome \t| preco |");
		for(Bebida b : lisBebida)
		{
			System.out.println("|" + b.getId() + "\t|" + b.getNome() + "\t|" + b.getPreco() + "\t|");
			
		}
		
		System.out.println("\naperte ENTER para voltar");
		scanner.nextLine();
		
	}
	
	//biscar um produto no cardapio
	public Produto Buscar(int n,String t)
	{
		if(t == "comida")
		{
			for(Produto c : lisComida)
			{
				
				if(n == c.getId())
				{
					return c;
				}
				
			}
			
		}
		else if(t == "bebida")
		{
			for(Produto b : lisBebida)
			{
				if(n == b.getId())
				{
					return b;
				}
				
			}
		}
		
		return null;
	}
}
