package Repor;

import java.util.ArrayList;
import java.util.Scanner;
import Classes.*;

 public class ReporFuncionario {
	
	Scanner scanner = new Scanner(System.in);
	
	private int id = 0;
	
	private static ArrayList<Gerente> lisGerente = new ArrayList<Gerente>();
	private static ArrayList<Garcom> lisGarcom = new ArrayList<Garcom>();
	
	public static void Criar()
	{
		
		Gerente g1 = new Gerente("eu","123",23,1);
		lisGerente.add(g1);
		Gerente g2 = new Gerente("eu1","123",21,1);
		lisGerente.add(g2);
		
		Garcom g = new Garcom("eu2","123",15,0);
		lisGarcom.add(g);
		
	}
	
	// inicio das funcoes get/set
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public static ArrayList<Gerente> getLisGerente() {
	 	return lisGerente;
	}
	
	public static void setLisGerente(ArrayList<Gerente> lisGerente) {
		ReporFuncionario.lisGerente = lisGerente;
	}
	
	public static ArrayList<Garcom> getLisGarcom() {
		return lisGarcom;
	}
	
	public static void setLisGarcom(ArrayList<Garcom> lisGarcom) {
		ReporFuncionario.lisGarcom = lisGarcom;
	}
		// fim das funcoes get/set
	 
	 //////////////////////////////
	
		//add novo funcionario
	public void AddFuncionario(int acesso)
	{
		String nome;
		String senha;
		id +=1;
		boolean v;
		Funcionario f;
		
		do
		{
			System.out.println("nome : ");
			nome = scanner.nextLine();
			v = BuscarNome(nome);
			
			if(v)
			{
				System.out.println("----- nome indisponivel -----");
			}
		}while(v);
		//scanner.nextLine();
		System.out.println("senha : ");
		senha = scanner.nextLine();
		
		//scanner.nextLine();
		
		if(acesso == 0) {
			
			lisGarcom.add(new Garcom(nome,senha,id,acesso));	
		}
		else
		{
			lisGerente.add(new Gerente(nome,senha,id,acesso));
		}
		
		f = Buscar(id,acesso);
		System.out.println("novo funcionario add");
		System.out.println("|id \t| nome \t| Acesso|");
		System.out.println("|" + f.getId() + "\t|" + f.getNome() + "\t|" + f.getAcesso() + "\t|");
		System.out.println("\naperte ENTER para voltar");
		scanner.nextLine();
		
	}
	
	//remover novo funcionario
	public void Remover(int n)
	{
		//boolean v = true;
		int nId;
		Funcionario f;
		do
		{
			try
			{
			System.out.println("digite o id");
			nId = scanner.nextInt();
			}
			catch(Exception e)
			{
				scanner.next();
				nId = 0;
			}
			f = Buscar(nId,n);
			if(f != null)
			{
				if(n == 1)
				{
					lisGerente.remove(f);
				}
				else
				{
					lisGarcom.remove(f);
				}
			}
			else
			{
				System.out.println("----- id invalido -----");
			}
			
			
		}while(f == null);
		
		System.out.println("funcionario removido");
		System.out.println("|id \t| nome \t| Acesso|");
		System.out.println("|" + f.getId() + "\t|" + f.getNome() + "\t|" + f.getAcesso() + "\t|");
		System.out.println("\naperte ENTER para voltar");
		scanner.nextLine();
		scanner.nextLine();
		
	    
	}
	
	// entra 
	public Funcionario Entra()
	{
		String nome;
		String senha;
		
		Funcionario f;
		
		do
		{
			System.out.print("nome: ");
		    nome = scanner.nextLine();
		    
		    f = Buscar(nome);
		    
		    if(f == null)
		    {
		    	System.out.println("----- usuario nao encontrado -----");
		    }
		}while(f == null);
		
		do
		{
			System.out.print("senha: ");
			senha = scanner.nextLine();
			
			if(!f.getSenha().equals(senha))
			{
				System.out.println("----- senha incorreta -----");
			}
			
		}while(!f.getSenha() .equals(senha));
		
		return f;
	}
	
	//buscar um funcionario
	public Funcionario Buscar(String n)
	{
		for(Funcionario f : lisGerente)
		{
			
			if(n.equals(f.getNome()))
			{
				return f;
			}
			
		}
		
		for(Funcionario f : lisGarcom)
		{
			
			if(n.equals(f.getNome()))
			{
				return f;
			}
			
		}
		
		return null;
	}
	
	//buscar funcionario de uma forma mais especifica
	public Funcionario Buscar(int nId, int n)
	{
		
		if(n == 1)
		{
			for(Funcionario f : lisGerente)
			{
				
				if(nId == f.getId())
				{
					return f;
				}
				
			}
		}
		else if(n == 0)
		{
			for(Funcionario f : lisGarcom)
			{
				if(nId == f.getId())
				{
					return f;
				}
				
			}
		}
		
		return null;
	}
	
	//buscar um gerente
	public Gerente BuscarG(int n)
	{
		for(Gerente g : lisGerente)
		{
			
			if(n == g.getId())
			{
				return g;
			}
			
		}
		return null;
	}
	
	//modificar dados do funcionario
	public void Alterar(int n)
	{
		//boolean v = true;
		int nId;
		Funcionario f;
		do
		{
			try
			{
			System.out.println("digite o id");
			nId = scanner.nextInt();
			}
			catch(Exception e)
			{
				scanner.next();
				nId = 0;
			}
			f = Buscar(nId,n);
			if(f != null)
			{
				System.out.println("nova senha : ");
				f.setSenha(scanner.next());
				do
				{
					
					try
					{
						System.out.println("novo acesso: ");
						f.setAcesso(scanner.nextInt());
						if(f.getAcesso() > 1 | f.getAcesso() < 0)
						{
							System.out.println("----- digite um numero de acesso valido -----");
						}
					}
					catch(Exception e)
					{
						System.out.println("----- digite um numero de acesso valido -----");
						scanner.next();
						f.setAcesso(2);
					}
					
				}while(f.getAcesso() > 1 || f.getAcesso() < 0);
			}
			else
			{
				System.out.println("----- numero invalido -----");
			}
			
			scanner.nextLine();
			
		}while(f == null);
		
		System.out.println("novos dados do funcionario");
		System.out.println("|id \t| nome \t| Acesso|");
		System.out.println("|" + f.getId() + "\t|" + f.getNome() + "\t|" + f.getAcesso() + "\t|");
		System.out.println("\naperte ENTER para voltar");
		scanner.nextLine();
	}
	
	//saber se um nome ja esta sendo usado pro outro funcionario
	public boolean BuscarNome(String n)
	{
		for(Funcionario f : lisGerente)
		{
			
			if(n.equals(f.getNome()))
			{
				return true;
			}
			
		}
		
		for(Funcionario f : lisGarcom)
		{
			if(n.equals(f.getNome()))
			{
				return true;
			}
			
		}
		
		return false;
	}

}
