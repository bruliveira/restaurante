package Classes;

import java.util.Scanner;
import Repor.*;

public class Menu {
	/////criar uma funcao para acessar as informaçoes do usuario nome /senha .....
	/////tratar o erro de digitar mais de uma palavra
	/////adicionar um  ver pedido para ver o que foi pedido
	////olhar as opcoes final selecionar escolher produtos e usuarios nao poder escolher outros nomes 
	
	Scanner scanner = new Scanner(System.in);
	
	ReporFuncionario rf = new ReporFuncionario();
	ReporProduto rp = new ReporProduto();
	ReporPedido rpd = new ReporPedido();
	Funcionario f ;
	int usuario;
	
	////////////////////////
	//////////////////////////
	
	///////logon 0
	public void Logon()
	{
		int opcao;
		
		do
		{
			try
			{
				System.out.println("_____________________________________");
				System.out.println("escolha um numero");
				System.out.println("-------------------------------------");
				System.out.println("1 login \n2 sair");
				System.out.println("_____________________________________");
				opcao = scanner.nextInt();
			}
			catch(Exception e)
			{
				scanner.next();
				opcao = 0;
			}
			switch(opcao)
			{
			case 1:
				f = rf.Entra();
				Login();
				break;
				
			case 2:
				System.out.println("saiu");
				break;
				
			default :
				System.out.println("-----numero invalido-----");
				break;
			}
			
		}while(opcao != 2);
	}
	
	/////////// opcao login 1
	void Login()
	{
		int opcao;
		do
		{
			try
			{
				System.out.println("_____________________________________");
				System.out.println("escolha um numero");
				System.out.println("-------------------------------------");
				System.out.println("1 cadastro \n2 pedidos \n3 logoff");
				System.out.println("_____________________________________");
				opcao = scanner.nextInt();
			}
			catch(Exception e)
			{
				scanner.next();
				opcao = 0;
			}
			switch(opcao)
			{
			case 1:
				if(f.getAcesso() == 1)
				{
					Cadastros();
				}
				else
				{
					System.out.println("----- voce nao tem acesso -----");
				}
				break;
				
			case 2:
				Pedidos();
				break;
			
			case 3:
				break;
				
			default :
				System.out.println("_____________________________________");
				System.out.println("----- numero invalido -----");
				break;
			}
			
		}while(opcao != 3);
	}
	
	///////// opcao login -> cadastros 2
	void Cadastros()
	{
		int opcao;
		do
		{
			try
			{
				System.out.println("_____________________________________");
				System.out.println("escolha um numero");
				System.out.println("-------------------------------------");
				System.out.println("1 funcionarios \n2 produtos \n3 voltar");
				System.out.println("_____________________________________");
				opcao = scanner.nextInt();
			}
			catch(Exception e)
			{
				scanner.next();
				opcao = 0;
			}
			switch(opcao)
			{
			case 1:
				Funcionarios();
				break;
				
			case 2:
				Produtos();
				break;
			
			case 3:

				break;
				
			default :
				System.out.println("----- numero invalido -----");
				break;
			}
			
		}while(opcao != 3);
	}
	
	//////////// opcao login -> pedidos 2
	void Pedidos()
	{
		int opcao;
		
		do
		{
			try
			{
				System.out.println("_____________________________________");
				System.out.println("escolha um numero");
				System.out.println("-------------------------------------");
				System.out.println("1 novo pedido \n2 lista de pedido \n3 remover pedido \n4 pagar pedido \n5 voltar");
				System.out.println("_____________________________________");
				opcao = scanner.nextInt();
			}
			catch(Exception e)
			{
				scanner.next();
				opcao = 0;
			}
			switch(opcao)
			{
			case 1:
				Pedido p;
				p = rpd.AddPedido();
				Pedido(p);
				break;
				
			case 2:
				rpd.MostraPedidos();
				break;
				
			case 3:
				rpd.RemoverPedido();
				break;
				
			case 4:
				rpd.Finalizar();
				break;
				
			case 5:
				break;
				
			default :
				System.out.println("----- numero invalido -----");
				break;
			}
			
		}while(opcao != 5);
	}
	
	/////////// opcao login -> cadastros -> funcionario 3
	void Funcionarios()
	{
		int opcao;
		int acesso;
		do
		{
			try
			{
				System.out.println("_____________________________________");
				System.out.println("escolha um numero");
				System.out.println("-------------------------------------");
				System.out.println("1 add funcionario \n2 lista de funcionarios \n3 editar funcionario \n4 remover funcionarios \n5 voltar");
				opcao = scanner.nextInt();
				System.out.println("_____________________________________");
			}
			catch(Exception e)
			{
				scanner.next();
				opcao = 0;
			}
			switch(opcao)
			{
			case 1:
				acesso = AcessoFuncionario();
				rf.AddFuncionario(acesso);
				break;
				
			case 2:
				 Gerente g = rf.BuscarG(f.getId());
				 g.LisFun();
				 
				break;
			
			case 3:
				acesso = AcessoFuncionario();
				rf.Alterar(acesso);
				break;
				
			case 4:
				acesso = AcessoFuncionario();
				rf.Remover(acesso);
				break;
				
			case 5:
				System.out.println("voltar");
				break;
				
			default :
				
				System.out.println("----- numero invalido -----");
				break;
			}
			
		}while(opcao != 5);
	}
	
	///////////// opcao login -> cadastros -> produto 3
	void Produtos()
	{
		int opcao;
		String tipo;
		do
		{
			try
			{
				System.out.println("_____________________________________");
				System.out.println("escolha um numero");
				System.out.println("-------------------------------------");
				System.out.println("1 add produto \n2 cardapio \n3 editar produto \n4 remover produto \n5 voltar");
				System.out.println("_____________________________________");
				opcao = scanner.nextInt();
			}
			catch(Exception e)
			{
				scanner.next();
				opcao = 0;
			}
			switch(opcao)
			{
			case 1:
				tipo = TipoProduto();
				rp.AddProduto(tipo);
				
				break;
				
			case 2:
				//tipo = TipoProduto();
				rp.VerProdutos();
				break;
			
			case 3:
				tipo = TipoProduto();
				rp.EditarProduto(tipo);
				
				break;
				
			case 4:
				tipo = TipoProduto();
				rp.RemoverProduto(tipo);
				break;
				
			case 5:
				System.out.println("voltar");
				break;
				
			default :
				System.out.println("----- numero invalido -----");
				break;
			}
			
		}while(opcao != 5);
	}
	//////////////////////////////// opcao login -> pedidos -> novo pedido 3
	void Pedido( Pedido p)
	{
		int opcao;
		String tipo;
		do
		{
			try
			{
				System.out.println("_____________________________________");
				System.out.println("escolha um numero");
				System.out.println("-------------------------------------");
				System.out.println("1 add produto \n2 ver pedido \n3 remover produto \n4 finalizar pedido \n5 voltar");
				System.out.println("_____________________________________");
				opcao = scanner.nextInt();
			}
			catch(Exception e)
			{
				scanner.next();
				opcao = 0;
			}
			switch(opcao)
			{
			case 1:
				tipo = TipoProduto();
				p.AddProduto(tipo);
				
				break;
				
			case 2:
				p.MostraPedido();
				break;
			
			case 3:
				tipo = TipoProduto();
				p.RemoverProduto(tipo);
				
				break;
				
			case 4:
				opcao = p.FinalizarPedido();
				break;
				
			case 5:
				ReporPedido.getLisPedidos().remove(p);
				break;
				
			default :
				System.out.println("_____________________________________");
				System.out.println("----- numero invalido -----");
				break;
			}
			
		}while(opcao != 5);
		
	}
	
	////////////////////escolher o tipo do produto 4
	String TipoProduto()
	{
		int opcao;
		do
		{
			try
			{
				System.out.println("_____________________________________");
				System.out.println("escolha um numero");
				System.out.println("-------------------------------------");
				System.out.println("1 comida \n2 bebida");
				opcao = scanner.nextInt();
				System.out.println("_____________________________________");
			}
			catch(Exception e)
			{
				scanner.next();
				opcao = 0;
			}
			switch(opcao)
			{
			case 1:
				System.out.println("comida");
				return "comida";
				
			case 2:
				System.out.println("bebida");
				return "bebida";
				
			default :
				System.out.println("----- numero invalido -----");
				break;
			}
			
		}while(true);
	}
	////////// escolher o acesso do funcionario 4
	int AcessoFuncionario()
	{
		int opcao;
		do
		{
			try
			{
				System.out.println("_____________________________________");
				System.out.println("escolha um numero");
				System.out.println("-------------------------------------");
				System.out.println("1 gerente \n2 garcom");
				System.out.println("_____________________________________");
				opcao = scanner.nextInt();
			}
			catch(Exception e)
			{
				scanner.next();
				opcao = 0;
			}
			switch(opcao)
			{
			case 1:
				System.out.println("gerente");
				return 1;
				
			case 2:
				System.out.println("garcom");
				return 0;
				
			default :
				System.out.println("----- numero invalido -----");
				break;
			}
			
		}while(true);
	}
	
}
