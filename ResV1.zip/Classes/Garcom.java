package Classes;

public class Garcom extends Funcionario {
	
	public Garcom(String nome, String senha, int id,int acesso)
	{
		super(nome,senha,id,acesso);
	}
}
