package Classes;

public class Bebida extends Produto {
	
	public Bebida(String tipo, String nome, double preco,int id)
	{
		super(tipo,nome,preco,id);
	}
}
