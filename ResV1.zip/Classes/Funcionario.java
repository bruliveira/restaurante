package Classes;


public class Funcionario {
	
	protected String nome;
	protected String senha;
	protected int id;
	protected int acesso;
	
	Funcionario(String nome, String senha, int id,int acesso)
	{
		this.acesso = acesso;
		this.nome = nome;
		this.senha = senha;
		this.id = id;
		
	}
	
	// inicio das funcoes get/set
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAcesso() {
		return acesso;
	}
	public void setAcesso(int acesso) {
		this.acesso = acesso;
	}
	
	// fim das funcoes get/set
}
