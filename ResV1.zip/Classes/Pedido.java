package Classes;

import java.util.ArrayList;
import java.util.Scanner;
import Repor.*;

public class Pedido {
	
	//////tratar a digitacao errada do id para ele nao aceitar um retorno null
	
	Scanner scanner = new Scanner(System.in);
	
	private  ArrayList<Comida> lisComida = new ArrayList<Comida>();
	private  ArrayList<Bebida> lisBebida = new ArrayList<Bebida>();
	private double precoTotal;
	private int mesa;
	private boolean pg;
	private int id;
	private double jpg;
	
	public Pedido(int mesa, int id)
	{
		this.mesa = mesa;
		this.id = id;
		precoTotal = 0;
		pg = false;
		jpg = 0;
	}
	
	//um construtor para uma gambiarra ,mas eu acho q nem precisa kkkk
	public Pedido()
	{
		
	}
	
	// inicio das funcoes get/set
		public double getPrecoTotal() {
			return precoTotal;
		}

		public void setPrecoTotal(double precoTotal) {
			this.precoTotal = precoTotal;
		}

		public int getMesa() {
			return mesa;
		}

		public void setMesa(int mesa) {
			this.mesa = mesa;
		}

		public boolean getPg() {
			return pg;
		}

		public void setPg(boolean pg) {
			this.pg = pg;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public double getJpg() {
			return jpg;
		}

		public void setJpg(double jpg) {
			this.jpg = jpg;
		}
		// fim das funcoes get/set
	
	/*public void PrecoTotal()
	{
		for(Comida c : lisComida)
		{
			
			precoTotal += c.getPreco();
			
		}
		
		for(Bebida b : lisBebida)
		{
			precoTotal += b.getPreco();
			
		}
	}*/
	
	//mostra o pedido q esta sendo feito
	public void MostraPedido()
	{
		int lc = lisComida.size();
		int lb =lisBebida.size();
		
		if(lc != 0)
		{
			System.out.println("\t\t ===== comida =====");
			System.out.println("-------------------------------------------------");
			System.out.println("|id \t| nome \t| preco | cont \t| preco Total \t|\n");
		}
		
		for(Comida c : lisComida)
		{
			System.out.println("|" + c.getId() + "\t|" + c.getNome() + "\t|" + c.getPreco() + "\t|" + c.getCont() + "\t|" + c.getPrecoTotal() +"\t|");
			
		}
		
		System.out.println();
		
		if(lb != 0)
		{
			System.out.println("\t\t ===== bebida =====");
			System.out.println("-------------------------------------------------");
			System.out.println("|id \t| nome \t| preco | cont \t| preco Total \t|\n");
		}
		for(Bebida b : lisBebida)
		{
			System.out.println("|" + b.getId() + "\t|" + b.getNome() + "\t|" + b.getPreco() + "\t|" + b.getCont() + "\t|" + b.getPrecoTotal() + "\t|");
			
		}
		
		if(lc == 0 && lb == 0)
		{
			System.out.println("nenhum pedido foi feito");
		}
		System.out.println("\naperte ENTER para voltar");
		scanner.nextLine();
		//scanner.nextLine();
	}
	/////////////////////////////////// nem sei se estas funcoes deveriam esta aqui kkkk
	
	// add produto ao pedido
	public void AddProduto(String tipo)
	{
		boolean v = true;
		int nId;
		//Produto p;
		do
		{
			try
			{
			System.out.println("digite o id");
			nId = scanner.nextInt();
			}
			catch(Exception e)
			{
				System.out.println("digite um numero");
				scanner.next();
				nId = 0;
			}
			
			if(nId != 0)
			{
				if(tipo == "comida")
				{
					Comida p = BuscarC(nId);
					if(p != null)
					{
						if(Buscar(nId,tipo))
						{
							p.AddCont();
							p.AddPrecototal();
						}
						else
						{
							lisComida.add(p);
						}
						System.out.println(p.getNome() + " add");
						v=false;
					}
				}
				else
				{
					Bebida p = BuscarB(nId);
					if(p != null)
					{
						if(Buscar(nId,tipo))
						{
							p.AddCont();
							p.AddPrecototal();
						}
						else
						{
							lisBebida.add(p);
						}
						System.out.println(p.getNome() + " add");
						v=false;
					}
				}
			}
			
			if(v) {
				System.out.println("id nao existe");
			}
			
		}while(v);
	}
	
	// buscar as comidas
	public Comida BuscarC(int n)
	{
		for(Comida c : ReporProduto.getLisComida())
		{
			
			if(n == c.getId())
			{
				return c;
			}
			
		}
		
		return null;
	}
	
	// buscar as bebidas
	public Bebida BuscarB(int n)
	{
		
		for(Bebida b : ReporProduto.getLisBebida())
		{
			if(n == b.getId())
			{
				return b;
			}
			
		}
		
		return null;
	}
	
	//remover produto do pedido
	public void RemoverProduto(String tipo)
	{
		boolean v = true;
		int nId;
		//Produto p;
		do
		{
			try
			{
			System.out.println("digite o id");
			nId = scanner.nextInt();
			}
			catch(Exception e)
			{
				System.out.println("digite um numero");
				scanner.next();
				nId = 0;
			}
			
			if(tipo == "comida")
			{
				Comida p = BuscarC(nId);
				if(p != null)
				{
					if(p.getCont() > 1)
					{
						p.RemoverCont();
						p.RemoverPrecototal();
					}
					else
					{
						lisComida.remove(p);
					}
					System.out.println(p.getNome() + " removido");
					v=false;
				}
			}
			else
			{
				Bebida p = BuscarB(nId);
				if(p != null)
				{
					if(p.getCont() > 1)
					{
						p.RemoverCont();
						p.RemoverPrecototal();
					}
					else
					{
						lisBebida.remove(p);
					}
					System.out.println(p.getNome() + " removido");
					v=false;
				}
			}
			
			if(v) {
				System.out.println("id nao existe");
			}
			
			
			
		}while(v);
		
	}
	//saber se a comida/bebida ja existe no pedido
	public boolean Buscar(int n,String t)
	{
		if(t == "comida")
		{
			for(Produto c : lisComida)
			{
				
				if(n == c.getId())
				{
					return true;
				}
				
			}
			
		}
		else
		{
			for(Produto b : lisBebida)
			{
				if(n == b.getId())
				{
					return true;
				}
				
			}
		}
		
		return false;
	}
	
	//////////////////////////////////////////////////////
	
	//finalizar pedido
	public int FinalizarPedido(/*Pedido p*/)
	{
		precoTotal = 0;
		for(Produto c : lisComida)
		{
			precoTotal += c.getPrecoTotal();
		}
		
		for(Produto b : lisBebida)
		{
			precoTotal += b.getPrecoTotal();
		}
		precoTotal -= jpg;
		if(!ReporPedido.getLisPedidosNPg().contains(this))
		{
			ReporPedido.getLisPedidosNPg().add(this);
		}
		
		/*System.out.println("comprovante do pedido");
		MostraPedido();*/
		
		
		return 5;
	}
}

