package Classes;

public class Produto {
	
	private String tipo;
	private String nome;
	private double preco;
	private int id;
	private int cont;
	private double precoTotal;
	
	public Produto(String tipo, String nome, double preco ,int id)
	{
		this.tipo = tipo;
		this.nome = nome;
		this.preco = preco;
		this.id = id;
		cont = 1;
		precoTotal = preco;
	}

	// inicio das funcoes get/set
	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public void  PrecoTotal()
	{
		precoTotal = preco * cont;
	}

	public int getCont() {
		return cont;
	}

	public void setCont(int cont) {
		this.cont = cont;
	}

	public double getPrecoTotal() {
		return precoTotal;
	}

	public void setPrecoTotal(double precoTotal) {
		this.precoTotal = precoTotal;
	}
	// fim das funcoes get/set
	
	//inicio das funcoes q mudam a quantidade de produtos iguais  e o  valor deles no pedido
	public void AddCont()
	{
		cont += 1;
	}
	
	public void AddPrecototal()
	{
		precoTotal += preco;
	}
	
	public void RemoverCont()
	{
		cont -= 1;
	}
	
	public void RemoverPrecototal()
	{
		precoTotal -= preco;
	}
	
	//fim das funcoes q mudam a quantidade de produtos iguais  e o  valor deles no pedido
}
