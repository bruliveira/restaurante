package Classes;

public class Comida extends Produto{
	
	public Comida(String tipo, String nome, double preco,int id)
	{
		super(tipo,nome,preco,id);
	}
}
