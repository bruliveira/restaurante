package Classes;

import java.util.Scanner;

import Repor.ReporFuncionario;

public class Gerente extends Funcionario {
	
	Scanner scanner = new Scanner(System.in);
	
	public Gerente(String nome, String senha, int id,int acesso)
	{
		super(nome,senha,id,acesso);
	}
	
	//funcao q lista todos os funcionarios
	public void LisFun()
	{
		System.out.println("\t gerentes");
		System.out.println("|id \t| nome \t| Acesso|");
		for(Funcionario f : ReporFuncionario.getLisGerente())
		{
			System.out.println("|" + f.getId() + "\t|" + f.getNome() + "\t|" + f.getAcesso() + "\t|");
			
		}
		
		System.out.println();
		System.out.println("\t garcons");
		System.out.println("|id \t| nome \t| Acesso|");
		for(Funcionario f : ReporFuncionario.getLisGarcom())
		{
			System.out.println("|" + f.getId() + "\t|" + f.getNome() + "\t|" + f.getAcesso() + "\t|");
			
		}
		System.out.println("\naperte ENTER para voltar");
		scanner.nextLine();
	}
}
