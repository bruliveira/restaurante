package Teste;

import Classes.Menu;
import Repor.*;

public class Tes {
	
	public static void main(String[] args)
	{
		Menu menu = new Menu();
		ReporProduto.Criar();
		ReporFuncionario.Criar();
		menu.Logon();
	}
}
